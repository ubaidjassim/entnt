const mockProducts = [
    {
        id: 1,
        name: 'Laptop',
        category: 'Electronics',
        price: "$999.99",
        stock: 50
    },
    {
        id: 2,
        name: 'Smartphone',
        category: 'Electronics',
        price: "$599.99",
        stock: 100
    },
    {
        id: 3,
        name: 'Headphones',
        category: 'Electronics',
        price: "$99.99",
        stock: 200
    },
    {
        id: 4,
        name: 'Camera',
        category: 'Electronics',
        price: "$19.99",
        stock: 300
    },
    {
        id: 5,
        name: 'Printer',
        category: 'Electronics',
        price: "$39.99",
        stock: 150
    },
    {
        id: 6,
        name: 'Keyboard',
        category: 'Electronics',
        price: "$49.99",
        stock: 80
    }
    // Add more products as needed
];

export default mockProducts;
